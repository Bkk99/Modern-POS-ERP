
import { GoogleGenAI } from "@google/genai";
import { Transaction, Product } from "../types";

// IMPORTANT: Do NOT configure the API key here.
// It is expected to be set in the environment variable `process.env.API_KEY`.
let ai: GoogleGenAI;
try {
    ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
} catch (error) {
    console.error("Gemini API key is not configured. Please set process.env.API_KEY.", error);
    // Fallback for environments without the key to prevent crashing
    ai = null!; 
}

const translateToEnglish = async (text: string): Promise<string> => {
    if (!ai || !text.trim()) return text; // return original text if no AI or empty

    const isLikelyEnglish = /^[a-zA-Z0-9\s,.-]+$/.test(text);
    if (isLikelyEnglish) {
        return text;
    }

    try {
        const prompt = `Translate the following Thai product name to a simple, descriptive English equivalent suitable for searching images. Only return the English translation, without any extra text or quotes.\n\nThai: "${text}"\n\nEnglish:`;
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                temperature: 0.1,
            }
        });
        
        let translatedText = response.text.trim().replace(/^"/, '').replace(/"$/, '');

        // If translation is empty or somehow failed, it might return the prompt text
        if (!translatedText || translatedText === text) {
            console.warn(`Translation for "${text}" failed, using original text.`);
            return text; 
        }

        return translatedText;
    } catch (error) {
        console.error(`Error translating text "${text}":`, error);
        return text; // Fallback to original text on error
    }
};


export const generateProductImage = async (productName: string): Promise<string> => {
    if (!ai) return `https://picsum.photos/seed/placeholder/400/400`;
    if (!productName.trim()) {
      return `https://picsum.photos/seed/placeholder/400/400`;
    }

    const englishProductName = await translateToEnglish(productName);
  
    const fallbackUrl = `https://source.unsplash.com/400x400/?${encodeURIComponent(englishProductName)}`;

    try {
      const prompt = `A high-quality, professional studio photo of "${englishProductName}". The item should be centered on a clean, plain white background. Food photography style.`;
      
      const response = await ai.models.generateImages({
        model: 'imagen-3.0-generate-002',
        prompt: prompt,
        config: {
            numberOfImages: 1,
            outputMimeType: 'image/jpeg',
            aspectRatio: '1:1',
        }
      });
  
      if (response.generatedImages && response.generatedImages.length > 0) {
          const image = response.generatedImages[0].image;
          const base64ImageBytes: string = image.imageBytes;
          const mimeType: string = image.mimeType || 'image/jpeg';
          return `data:${mimeType};base64,${base64ImageBytes}`;
      }
      
      console.warn(`AI image generation failed for "${productName}", using fallback.`)
      return fallbackUrl;
    } catch (error) {
      console.error(`Error generating product image for "${productName}":`, error);
      return fallbackUrl;
    }
  };


export const generateProductDescription = async (productName: string): Promise<string> => {
  if (!ai) return "AI service is not available.";
  if (!productName.trim()) {
    return "";
  }
  try {
    const prompt = `Create a short, appealing product description for a product named "${productName}". The description should be suitable for a POS system, around 15-25 words. Focus on key features or benefits. The response must be in Thai.`;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt
    });

    return response.text.trim();
  } catch (error) {
    console.error("Error generating product description:", error);
    return "Failed to generate description. Please enter one manually.";
  }
};

export const summarizeSales = async (transactions: Transaction[], products: Product[]): Promise<string> => {
    if (!ai) return "AI service is not available.";
    if(transactions.length === 0) {
        return "ยังไม่มีข้อมูลการขายสำหรับวันนี้";
    }

    const simplifiedTransactions = transactions.map(t => ({
        id: t.id,
        total: t.total,
        itemCount: t.items.reduce((sum, item) => sum + item.quantity, 0),
        items: t.items.map(i => `${i.name} (x${i.quantity})`).join(', ')
    })).slice(0, 10); // Limit to recent 10 for prompt length

    const prompt = `You are a helpful business assistant for a retail store owner in Thailand.
    Based on the following recent sales data, provide a short, insightful summary in Thai.
    Highlight the top-selling product if obvious, the total number of transactions, and the total revenue.
    Keep the summary encouraging and easy to read.

    Data:
    - Total Transactions: ${transactions.length}
    - Total Revenue: ${transactions.reduce((sum, t) => sum + t.total, 0).toFixed(2)} THB
    - Recent Transactions: ${JSON.stringify(simplifiedTransactions)}
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                temperature: 0.5,
            }
        });
        return response.text.trim();
    } catch (error) {
        console.error("Error summarizing sales:", error);
        return "ไม่สามารถสร้างสรุปยอดขายได้ในขณะนี้";
    }
}
